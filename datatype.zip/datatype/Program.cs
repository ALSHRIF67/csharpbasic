﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
// data type project and how they work 
//int a = 21;
// you cant store double in  int 
//int b = 40.7;
//int b = (int)40.7;
//int d = a + b;
//double c = 38.5;
//float g = 38.90f;
//double d = c + g;
//Console.WriteLine(d);
decimal a = 42.1M;
decimal b = 53.2M;
decimal c = a + b;
Console.WriteLine(c);
string w = "omer";
Console.WriteLine(w);
